# Multisim 工具链说明

## 已验证环境

- Multisim 程序：`C:\Program Files (x86)\National Instruments\Circuit Design Suite 14.3\multisim.exe`
- 已验证版本：Multisim 14.3
- COM ProgID：`MultisimInterface.MultisimApp`
- 必须使用：带 pywin32 的 32 位 Python
- 已验证 Python：`C:\Users\syfdy\.codex\tools\multisim-py32-bridge\python32\python.exe`

## COM 桥探测命令

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\syfdy\.codex\tools\multisim-py32-bridge\bridge.ps1 probe
```

期望结果：

- `python_bits=32`
- `com_connect_ok=true`
- `com_type=IMultisimApp`

## 已使用的 COM 能力

- `Connect`
- `OpenFile`
- `EnumComponents`
- `RLCValue`
- `SetRLCValue`
- `Save`
- `SaveAs`
- `RunSimulation`

## 当前自动化边界

当前工具链已经能稳定完成：

- 打开已有 `.ms14` 工程。
- 枚举元件。
- 读取 R/C 元件值。
- 修改 R/C 元件值。
- 保存候选工程。
- 运行仿真。

这套工具链特别适合“基于已有模板持续调参和优化”。如果用户要求从空白页面自动搭完整电路，可能还需要更多 Multisim COM 方法、UI 自动化，或者先准备可复用模板电路。当前最稳的策略是：从已知模板 `.ms14` 出发，替换参数和子电路，并让用户用截图确认视觉布局。

## 安全规则

- 永远编辑复制后的 `.ms14`，不要直接覆盖原始工程。
- 原始项目、课程模板、最终报告都要保留备份。
- 修改后必须读取元件值确认写入成功。
- 不能导出波形数据时，以示波器截图和光标读数作为最终证据。
- 每个候选都要记录：用户需求、复制文件、修改参数、预期效果、仿真状态、截图证据、是否接受。
