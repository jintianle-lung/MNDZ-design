# Multisim 课程设计自然语言仿真 Skill

这是一个给 Codex 使用的 Multisim 自动化与课程设计辅助 skill。它的目标是让用户可以直接用自然语言提出需求，例如：

- “三角波幅度太大了，帮我调到 4Vpp。”
- “正弦波有点失真，继续优化。”
- “按课程要求检查这套电路。”
- “把 R1 改成 75k，再跑一下仿真。”
- “根据波形截图帮我判断哪里不对。”

这个 skill 会把这些需求转成可执行步骤：读取 `.ms14` 工程参数、复制候选工程、修改元件值、运行 Multisim、对照示波器波形、继续迭代，最后生成报告说明。

## 目录内容

- `SKILL.md`：给 Codex 读取的核心工作流。
- `scripts/`：通过 32 位 COM 控制 Multisim 的脚本。
- `references/`：工具链说明、自然语言工作流、截图检查点、报告示例。
- `assets/`：示例修正版 `.ms14` 工程和代表性波形截图。

## 已验证工具链

- Multisim 14.3
- COM ProgID：`MultisimInterface.MultisimApp`
- 32 位 Python：`C:\Users\syfdy\.codex\tools\multisim-py32-bridge\python32\python.exe`

探测命令：

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\syfdy\.codex\tools\multisim-py32-bridge\bridge.ps1 probe
```

期望结果包括：

- `python_bits=32`
- `com_connect_ok=true`
- `com_type=IMultisimApp`

## 自然语言仿真流程

1. 理解用户目标：要改什么波形、哪个参数、按什么指标验收。
2. 读取当前 `.ms14` 元件参数。
3. 必要时查资料或用电路公式推理候选方案。
4. 复制工程，修改候选参数，不覆盖原始文件。
5. 通过 32 位 COM 桥运行 Multisim。
6. 对照课程要求和示波器截图判断是否合格。
7. 继续迭代，直到波形和报告证据都能说明问题。

## 本次示例结果

示例工程来自 LM324 综合课设：自制 5 kHz 三角波，与 500 Hz 正弦信号相加，再通过二阶有源低通滤波器恢复正弦信号。

最终结果：

- 三角波约 `4.178 Vpp`，接近 `5 kHz`。
- 滤波输出约 `4.977 Vpp`，正弦波无明显失真。

## GitHub 地址

占位链接：`https://github.com/<your-name>/multisim-course-design`
