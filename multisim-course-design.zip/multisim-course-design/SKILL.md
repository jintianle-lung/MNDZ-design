---
name: multisim-course-design
description: 面向 NI Multisim 的自然语言仿真、调参和模拟电路迭代设计 skill。适用于用户提出“帮我修改参数”“这个波形幅度不对”“按课程要求检查”“继续优化失真”“生成报告”等需求；可基于 .ms14 工程读取元件值、修改候选参数、运行 32 位 Multisim COM 自动化、对照示波器波形和课程指标持续改进。
---

# Multisim 课程设计自然语言仿真 Skill

这个 skill 的目标不是只保存一次课设结果，而是把“用户用自然语言提需求 -> AI 分析电路 -> 修改 Multisim 候选工程 -> 运行仿真 -> 对照波形继续改进”的流程沉淀下来。它特别适合 LM324、滤波器、振荡器、加法器等模拟电路课程设计。

## 总体流程

1. 先把用户的话翻译成明确任务：目标波形、当前问题、允许修改的元件、需要的证据、最终交付物。
2. 对照课程要求列检查点：完整电路图、各级局部电路、三角波输出、加法器输出、滤波输出、报告说明。
3. 使用 Multisim 自动化前，先验证工具链：
   - 必须使用 32 位 Python，普通 64 位 Python 不能稳定调用 Multisim COM。
   - 推荐运行时：`C:\Users\syfdy\.codex\tools\multisim-py32-bridge\python32\python.exe`。
   - COM ProgID：`MultisimInterface.MultisimApp`。
4. 永远复制 `.ms14` 工程后再修改，不覆盖原始工程和模板。
5. 用 `scripts/extract_component_values.py` 读取当前 R/C 元件值。
6. 每轮只做一个小候选修改；除非用户明确要求扫参，不要一次改很多地方。
7. 用 `scripts/set_values_in_place.py` 修改候选工程；滤波器扫参可用 `scripts/make_filter_variant_param.py`。
8. 用 `scripts/open_and_run_multisim.py` 打开并运行候选工程。
9. 能导出数据就用数据判断；不能导出时，请用户提供示波器截图和光标读数。
10. 每轮记录：改了什么、为什么改、预期效果、实测结果、是否接受。
11. 最终输出：修正版 `.ms14`、截图检查说明、报告正文、可选 Git/skill 更新。

## 自然语言请求怎么处理

详细规则见 `references/natural-language-workflow.md`。

常见说法和处理方式：

- “幅度太大/太小”：先判断是哪一级，优先调增益或施密特阈值，再看是否需要补偿周期。
- “周期不对/频率不对”：优先调定时元件，即 `R*C` 时间常数，不要先动放大倍数。
- “正弦波失真/有毛刺”：检查是否削顶、滤波器截止频率是否过高、Q 值是否合适、5 kHz 残留是否太大。
- “输出不够 5Vpp”：先确认前级信号是否合格，再考虑增加滤波器或放大器增益。
- “按课程要求检查”：从任务书建立检查表，逐级检查截图和光标读数。
- “帮我改参数”：复制工程，只改指定元件或最小必要元件，保存候选，运行仿真，请用户给波形证据。
- “继续优化”：对比上一版已接受波形和目标指标，做下一步最小修改。

## 常用命令

探测 Multisim COM 桥：

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\syfdy\.codex\tools\multisim-py32-bridge\bridge.ps1 probe
```

读取元件值：

```powershell
& C:\Users\syfdy\.codex\tools\multisim-py32-bridge\python32\python.exe scripts\extract_component_values.py path\to\design.ms14
```

在复制后的工程中修改 R/C 值：

```powershell
& C:\Users\syfdy\.codex\tools\multisim-py32-bridge\python32\python.exe scripts\set_values_in_place.py path\to\copy.ms14 --pairs R1=75000 C1=0.000000110
```

运行仿真：

```powershell
& C:\Users\syfdy\.codex\tools\multisim-py32-bridge\python32\python.exe scripts\open_and_run_multisim.py path\to\copy.ms14 --seconds 0.25 --settle 2
```

## 设计判断规则

- 本课设三角波目标：约 `+2 V` 到 `-2 V`，即 `4 Vpp`，周期 `T=0.2 ms`，频率 `5 kHz`。
- 三角波幅度过大时，优先降低施密特触发阈值；若周期随之变化，再补偿积分电容或积分电阻。
- 加法器目标：`ui2 = 20ui1 + uo1`，其中 `ui1 = 0.1 sin(2*pi*500*t) V`。
- 滤波器目标：保留 500 Hz 分量接近 `5 Vpp`，尽量压低 5 kHz 三角波残留。
- 本包最终示例参数：`R1=75 kOhm`，`C1=110 nF`，`R10=R11=14.5 kOhm`，`C2=C4=22 nF`，`R12=22 kOhm`，`R13=14.5 kOhm`。
- 优先修前级，不要用后级增益掩盖前级波形错误。
- 每轮最多改两个强耦合参数，例如三角波中同时改阈值电阻和积分电容。
- 预测值只用于指导，最终以 Multisim 示波器光标读数为准。
- 当拓扑、公式、器件极限不确定时，先查数据手册、应用笔记或课程资料，再改电路。

## 报告写作规则

截图光标检查见 `references/checkpoints.md`，本次报告示例见 `references/report-example.md`。

报告里要讲清楚：

- 每一级电路做什么。
- 为什么选择这个拓扑。
- 为什么元件取这个值。
- 调试中出现了什么问题。
- AI 和工具链如何帮助发现问题、提出候选修改。
- 哪些最终波形读数证明满足课程要求。

本课设最终可写入报告的实测结果：

- 三角波：约 `4.178 Vpp`；峰到谷光标时间约 `103.290 us`，所以完整周期约 `0.206 ms`。
- 滤波输出：约 `4.977 Vpp`；500 Hz 正弦波平滑，无明显削顶。

## 维护这个 skill

后续每完成一个新的 Multisim 项目，都可以继续补充：

1. 可复用自动化脚本放入 `scripts/`。
2. 稳定的设计流程、公式、检查表放入 `references/`。
3. 小体积且有代表性的工程和截图放入 `assets/`。
4. 至少运行一个代表性命令验证，再提交 Git。
