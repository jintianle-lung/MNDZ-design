from __future__ import annotations

import argparse
import json

import win32com.client


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("path")
    parser.add_argument("--pairs", nargs="+", required=True, help="NAME=VALUE")
    args = parser.parse_args()

    updates = {}
    for pair in args.pairs:
        name, value = pair.split("=", 1)
        updates[name] = float(value)

    app = win32com.client.gencache.EnsureDispatch("MultisimInterface.MultisimApp")
    app.Connect()
    doc = app.OpenFile(args.path)

    changed = {}
    for name, value in updates.items():
        before = float(doc.RLCValue(name))
        doc.SetRLCValue(name, value)
        changed[name] = {"before": before, "after": float(doc.RLCValue(name))}
    saved = bool(doc.Save())
    print(json.dumps({"path": args.path, "saved": saved, "changed": changed}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
