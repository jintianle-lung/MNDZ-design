const fs = require("fs");
const path = require("path");
const {
  AlignmentType,
  BorderStyle,
  Document,
  HeadingLevel,
  ImageRun,
  Math: DocxMath,
  MathFraction,
  MathRadical,
  MathRun,
  MathSubScript,
  MathSuperScript,
  Packer,
  PageBreak,
  Paragraph,
  Table,
  TableCell,
  TableOfContents,
  TableRow,
  TextRun,
  UnderlineType,
  WidthType,
} = require("docx");

const root = "C:\\Users\\syfdy\\Desktop\\Multisim_课程设计_14500优化版";
const reportDir = path.join(root, "02_报告材料");
const assetsDir = path.join(reportDir, "assets");
const outputsDir = "C:\\Users\\syfdy\\Documents\\Codex\\2026-06-26\\gai\\outputs";
const imageMeta = JSON.parse(fs.readFileSync(path.join(assetsDir, "image_meta.json"), "utf8").replace(/^\uFEFF/, ""));
const outBase = "集成运算放大器的应用_课程设计报告_靳天乐_2023141080190_正式深化版";

const files = {
  docx: path.join(reportDir, `${outBase}.docx`),
  md: path.join(reportDir, `${outBase}.md`),
  html: path.join(reportDir, `${outBase}.html`),
  logo: path.join(assetsDir, "sichuan_university_logo.png"),
};

const refs = [
  "Texas Instruments, LM324, LM324A, LM224, LM2902 Quadruple Operational Amplifiers datasheet, https://www.ti.com/product/LM324",
  "Texas Instruments, Analysis of the Sallen-Key Architecture, Application Report SLOA024, https://www.ti.com/lit/pdf/sloa024",
  "Texas Instruments, Active Low-Pass Filter Design, Application Report SLOA049, https://www.ti.com/lit/pdf/sloa049",
  "National Instruments, Multisim Oscilloscope documentation, https://www.ni.com/docs/en-US/bundle/multisim/page/topics/oscilloscope.html",
];

const figuresMain = [
  ["fig02_overall_circuit_wide.png", "图1  最终整体电路", "整体电路按“振荡器—加法器—低通滤波器”组织，XSC1、XSC2、XSC3 分别观察三角波、加法输出和滤波输出。", 560],
  ["fig03_triangle_unit.png", "图2  三角波发生器局部", "U1A 构成比较/施密特触发环节，D1/D2 进行限幅；U1B 与 C1 构成积分器，产生三角波。", 520],
  ["fig01_xsc1_triangle_wave.png", "图3  三角波输出 XSC1", "最终三角波约为 +2.264 V 到 -1.913 V，峰峰值约 4.178 V；峰到谷约 103.290 us，完整周期约 0.206 ms。", 560],
  ["fig06_adder_unit.png", "图4  加法器局部", "该级将 0.1 V 的 500 Hz 正弦信号按 20 倍权重叠加到三角波上，形成后级滤波器输入。", 460],
  ["fig04_xsc2_adder_output.png", "图5  加法输出 XSC2", "可观察到 500 Hz 正弦包络上叠加 5 kHz 三角波分量，符合 ui2=20ui1+uo1。", 560],
  ["fig09_filter_unit.png", "图6  二阶 Sallen-Key 低通滤波器", "R10、R11、C2、C4 主要决定截止频率，R12、R13 设置非反相通带增益。", 500],
  ["fig07_xsc3_filter_output.png", "图7  滤波输出 XSC3", "输出峰峰值约 4.977 V，接近课程要求 5 Vpp，波形无明显削顶和高频毛刺。", 560],
  ["fig08_overall_circuit_final.png", "图8  最终观察点布置", "三个示波器形成逐级验证证据链，避免只看最终输出而忽略前级指标。", 560],
];

const figFail = ["fig00_failed_triangle_wave.png", "图9  调试中发现的旧版三角波幅度偏大问题", "旧版三角波约 +3.923 V 到 -3.197 V，峰峰值约 7.120 V，明显高于课程要求的 4 Vpp，因此需回到三角波发生器修改阈值与积分时间常数。", 560];

function r(text, opts = {}) {
  return new TextRun({
    text,
    font: { ascii: opts.asciiFont || "Times New Roman", eastAsia: opts.cnFont || "宋体" },
    size: opts.size || 24,
    bold: opts.bold || false,
    italics: opts.italics || false,
    underline: opts.underline,
  });
}

function p(text, opts = {}) {
  return new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    heading: opts.heading,
    spacing: { before: opts.before ?? 80, after: opts.after ?? 80, line: opts.line ?? 360 },
    indent: opts.indent ? { firstLine: opts.indent } : undefined,
    children: Array.isArray(text) ? text : [r(text, opts)],
  });
}

const h1 = (t) => p(t, { heading: HeadingLevel.HEADING_1, cnFont: "黑体", bold: true, size: 32, before: 280, after: 160 });
const h2 = (t) => p(t, { heading: HeadingLevel.HEADING_2, cnFont: "黑体", bold: true, size: 28, before: 220, after: 100 });

function mRun(text) { return new MathRun(text); }
function sub(base, s) { return new MathSubScript({ children: [mRun(base)], subScript: [mRun(s)] }); }
function sup(base, s) { return new MathSuperScript({ children: [mRun(base)], superScript: [mRun(s)] }); }
function frac(num, den) { return new MathFraction({ numerator: Array.isArray(num) ? num : [mRun(num)], denominator: Array.isArray(den) ? den : [mRun(den)] }); }
function sqrt(children) { return new MathRadical({ children }); }
function mathPara(children) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 100, after: 100 },
    children: [new DocxMath({ children })],
  });
}

function table(rows, widths) {
  const border = { style: BorderStyle.SINGLE, size: 1, color: "888888" };
  return new Table({
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((row, idx) => new TableRow({
      children: row.map((cell, i) => new TableCell({
        width: { size: widths[i], type: WidthType.DXA },
        borders: { top: border, bottom: border, left: border, right: border },
        margins: { top: 80, bottom: 80, left: 100, right: 100 },
        children: [p(cell, { align: AlignmentType.CENTER, cnFont: idx === 0 ? "黑体" : "宋体", bold: idx === 0, size: 21, line: 300, before: 20, after: 20 })],
      })),
    })),
  });
}

function imageBlock([file, title, note, width]) {
  const [w, h] = imageMeta[file];
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 120, after: 60 },
      children: [new ImageRun({
        type: "png",
        data: fs.readFileSync(path.join(assetsDir, file)),
        transformation: { width, height: Math.round(width * h / w) },
        altText: { title, description: note, name: file },
      })],
    }),
    p(title, { align: AlignmentType.CENTER, cnFont: "黑体", bold: true, size: 22, before: 20, after: 30 }),
    p(`说明：${note}`, { indent: 420, size: 22, line: 320, before: 20, after: 110 }),
  ];
}

function cover() {
  const [lw, lh] = imageMeta["sichuan_university_logo.png"];
  const field = (label, val) => new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 130, after: 130 },
    children: [r(label, { size: 30 }), r("　　", { size: 30 }), r(val.padStart(14, " "), { cnFont: "楷体", size: 30, bold: true, underline: { type: UnderlineType.SINGLE } })],
  });
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 60, after: 360 }, children: [new ImageRun({ type: "png", data: fs.readFileSync(files.logo), transformation: { width: 130, height: Math.round(130 * lh / lw) }, altText: { title: "四川大学校徽", description: "四川大学校徽", name: "scu-logo" } })] }),
    field("题　　目", "集成运算放大器的应用"),
    field("学　　院", "生物医学工程学院"),
    field("专　　业", "医学信息工程"),
    field("学生姓名", "靳天乐"),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 130, after: 130 }, children: [r("学　　号", { size: 30 }), r("　　", { size: 30 }), r("2023141080190", { size: 30, bold: true, underline: { type: UnderlineType.SINGLE } }), r(" 年级　", { size: 30 }), r("24 级", { cnFont: "楷体", size: 30, bold: true, underline: { type: UnderlineType.SINGLE } })] }),
    p("", { after: 1700 }),
    p("教务处制表", { align: AlignmentType.CENTER, size: 28 }),
    p("二〇二六年五月二十七日", { align: AlignmentType.CENTER, size: 28 }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

const md = `# 集成运算放大器的应用课程设计报告（正式深化版）

## 一、设计依据与任务分解

本设计的电路方案不是凭经验随意搭建，而是从课程任务书的信号链要求出发：先产生高频三角波，再与低频正弦按比例相加，最后通过低通滤波选出 500 Hz 正弦分量。资料依据主要包括 LM324 数据手册、TI Sallen-Key 有源低通滤波器应用资料和 Multisim 示波器文档。

低频输入为

$$u_{i1}=0.1\\sin(2\\pi\\cdot500t)\\ \\mathrm{V}$$

加法器目标为

$$u_{i2}=20u_{i1}+u_{o1}$$

最终输出要求为 500 Hz、约 5 Vpp 的正弦波，无明显失真。

## 二、总体方案来源

根据任务书，电路必须同时含有信号产生、加法和选频滤波三个功能，因此采用三段式结构：施密特触发器加积分器产生三角波；运放加法器实现比例叠加；二阶 Sallen-Key 低通滤波器抑制 5 kHz 三角波分量并保留 500 Hz 正弦分量。该结构的优点是每一级都有明确指标，可用示波器逐级验证。

## 三、三角波发生器理论计算与参数选取

三角波发生器的设计依据是“比较器翻转阈值决定幅度，积分器时间常数决定斜率和周期”。积分器近似满足

$$\\frac{du_o}{dt}\\approx-\\frac{u_{in}}{R_4C_1}$$

因此，当施密特触发阈值降低时，三角波幅度会降低；但周期也会变短，需要增大积分电容补偿。最终选取 $R_1=75\\ \\mathrm{k\\Omega}$、$C_1=110\\ \\mathrm{nF}$，使 XSC1 测得三角波约 4.178 Vpp，完整周期约 0.206 ms。

## 四、加法器设计与参数依据

课程要求 $u_{i2}=20u_{i1}+u_{o1}$。由于 $u_{i1}$ 峰值只有 0.1 V，乘以 20 后峰值约为 2 V，正好与三角波约 ±2 V 的量级匹配。因此加法器的核心不是单纯放大，而是让低频正弦和高频三角波在同一量级上叠加，为后续滤波提供包含两类频率成分的输入。

## 五、低通滤波器理论计算与参数依据

低通滤波器采用二阶 Sallen-Key 结构。非反相通带增益为

$$K=1+\\frac{R_{13}}{R_{12}}=1+\\frac{14.5}{22}\\approx1.659$$

截止频率估算为

$$f_c=\\frac{1}{2\\pi\\sqrt{R_{10}R_{11}C_2C_4}}\\approx499\\ \\mathrm{Hz}$$

选择接近 500 Hz 的截止频率，是为了保留目标正弦分量，同时对 5 kHz 高频三角波分量形成明显衰减。估算品质因数约 $Q\\approx0.746$，不会产生过强尖峰，因此最终正弦波较平滑。

## 六、仿真结果

${figuresMain.map(([file, title, note]) => `![${title}](assets/${file})\n\n${note}`).join("\n\n")}

## 七、调试讨论：旧版为什么失败，如何优化

旧版失败不在于没有最终输出，而在于前级三角波源信号不符合课程指标。旧版 XSC1 测得约 +3.923 V 到 -3.197 V：

$$V_{pp,old}=3.923-(-3.197)=7.120\\ \\mathrm{V}$$

这比目标 4.000 Vpp 大约

$$\\frac{7.120}{4.000}\\approx1.78$$

因此不能通过调后级滤波器掩盖该问题，而应回到三角波发生器降低施密特阈值。按目标比例估算：

$$\\frac{4.000}{7.120}\\approx0.562$$

将 $R_1$ 从 130 kΩ 调到 75 kΩ，有

$$\\frac{75}{130}\\approx0.577$$

与所需比例接近。因为阈值降低会使翻转提前、周期变短，所以将 $C_1$ 从 68 nF 增大到 110 nF 进行周期补偿。最终形成 triangle_fixed 版本。

![图9  旧版三角波幅度偏大](assets/fig00_failed_triangle_wave.png)

旧版三角波约 7.120 Vpp，明显超过 4 Vpp 要求，是本次优化的关键证据。

## 八、AI 辅助与设计思考

AI 主要用于四方面：整理任务书检查点；查阅 LM324 与 Sallen-Key 滤波器资料；恢复 Multisim 32 位 COM 工具链以读取和修改参数；根据示波器光标读数进行参数推理。最终电路不是由 AI 直接给出，而是根据课程指标、器件资料、理论公式和 Multisim 仿真证据逐步收敛得到。

## 九、结论

最终电路实现了三角波发生、加法和低通滤波三个功能。XSC1 显示三角波约 4.178 Vpp、周期约 0.206 ms；XSC2 显示混合信号符合加法关系；XSC3 显示滤波输出约 4.977 Vpp，无明显失真。设计满足课程要求。

## 参考文献

${refs.map((x, i) => `[${i + 1}] ${x}`).join("\n")}
`;

function html(markdown) {
  let body = markdown
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/^# (.*)$/gm, "<h1>$1</h1>").replace(/^## (.*)$/gm, "<h2>$1</h2>")
    .replace(/!\[(.*?)\]\((.*?)\)/g, '<figure><img src="$2" alt="$1"><figcaption>$1</figcaption></figure>')
    .replace(/\n\n/g, "</p><p>").replace(/<p><h/g, "<h").replace(/<\/h([12])><\/p>/g, "</h$1>")
    .replace(/<p><figure>/g, "<figure>").replace(/<\/figure><\/p>/g, "</figure>");
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>课程设计报告</title><script>window.MathJax={tex:{inlineMath:[['$','$'],['\\\\(','\\\\)']]},svg:{fontCache:'global'}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script><style>body{font-family:SimSun,serif;max-width:900px;margin:40px auto;line-height:1.8}h1,h2{font-family:SimHei,sans-serif}img{max-width:100%}figure{text-align:center}p{text-indent:2em}</style></head><body><p>${body}</p></body></html>`;
}

async function docx() {
  const children = [];
  children.push(...cover());
  children.push(p("目  录", { align: AlignmentType.CENTER, cnFont: "黑体", bold: true, size: 34 }));
  children.push(new TableOfContents("目录", { hyperlink: true, headingStyleRange: "1-3" }));
  children.push(new Paragraph({ children: [new PageBreak()] }));

  children.push(h1("一、设计依据与任务分解"));
  children.push(p("本设计的电路方案不是凭经验随意搭建，而是从课程任务书的信号链要求出发：先产生高频三角波，再与低频正弦按比例相加，最后通过低通滤波选出 500 Hz 正弦分量。资料依据主要包括 LM324 数据手册、TI Sallen-Key 有源低通滤波器应用资料和 Multisim 示波器文档。", { indent: 420 }));
  children.push(mathPara([sub("u", "i1"), mRun("=0.1sin(2π·500t) V")]));
  children.push(mathPara([sub("u", "i2"), mRun("=20"), sub("u", "i1"), mRun("+"), sub("u", "o1")]));
  children.push(table([["指标", "要求", "最终结果"], ["三角波", "5 kHz，约 4 Vpp", "4.178 Vpp，周期约 0.206 ms"], ["加法输出", "ui2=20ui1+uo1", "低频包络叠加高频三角波"], ["滤波输出", "500 Hz，约 5 Vpp", "4.977 Vpp，无明显失真"]], [2200, 3400, 3400]));

  children.push(h1("二、总体方案来源"));
  children.push(p("根据任务书，电路必须同时含有信号产生、加法和选频滤波三个功能，因此采用三段式结构：施密特触发器加积分器产生三角波；运放加法器实现比例叠加；二阶 Sallen-Key 低通滤波器抑制 5 kHz 三角波分量并保留 500 Hz 正弦分量。该结构的优点是每一级都有明确指标，可用示波器逐级验证。", { indent: 420 }));

  children.push(h1("三、三角波发生器理论计算与参数选取"));
  children.push(p("三角波发生器的设计依据是“比较器翻转阈值决定幅度，积分器时间常数决定斜率和周期”。积分器近似满足：", { indent: 420 }));
  children.push(mathPara([frac([mRun("d"), sub("u", "o")], [mRun("dt")]), mRun("≈-"), frac([sub("u", "in")], [mRun("R"), sub("", "4"), mRun("C"), sub("", "1")])]));
  children.push(p("因此，当施密特触发阈值降低时，三角波幅度会降低；但周期也会变短，需要增大积分电容补偿。最终选取 R1=75 kΩ、C1=110 nF，使 XSC1 测得三角波约 4.178 Vpp，完整周期约 0.206 ms。", { indent: 420 }));

  children.push(h1("四、加法器设计与参数依据"));
  children.push(p("课程要求 ui2=20ui1+uo1。由于 ui1 峰值只有 0.1 V，乘以 20 后峰值约为 2 V，正好与三角波约 ±2 V 的量级匹配。因此加法器的核心不是单纯放大，而是让低频正弦和高频三角波在同一量级上叠加，为后续滤波提供包含两类频率成分的输入。", { indent: 420 }));

  children.push(h1("五、低通滤波器理论计算与参数依据"));
  children.push(p("低通滤波器采用二阶 Sallen-Key 结构。R10、R11、C2、C4 主要决定截止频率，R12、R13 设置非反相通带增益。", { indent: 420 }));
  children.push(mathPara([mRun("K=1+"), frac([sub("R", "13")], [sub("R", "12")]), mRun("=1+14.5/22≈1.659")]));
  children.push(mathPara([sub("f", "c"), mRun("="), frac([mRun("1")], [mRun("2π"), sqrt([sub("R", "10"), sub("R", "11"), sub("C", "2"), sub("C", "4")])]), mRun("≈499 Hz")]));
  children.push(p("选择接近 500 Hz 的截止频率，是为了保留目标正弦分量，同时对 5 kHz 高频三角波分量形成明显衰减。估算 Q≈0.746，不会产生过强尖峰，因此最终正弦波较平滑。", { indent: 420 }));

  children.push(h1("六、仿真结果"));
  for (const fig of figuresMain) children.push(...imageBlock(fig));

  children.push(h1("七、调试讨论：旧版为什么失败，如何优化"));
  children.push(p("旧版失败不在于没有最终输出，而在于前级三角波源信号不符合课程指标。旧版 XSC1 测得约 +3.923 V 到 -3.197 V：", { indent: 420 }));
  children.push(mathPara([sub("V", "pp,old"), mRun("=3.923-(-3.197)=7.120 V")]));
  children.push(mathPara([frac(["7.120"], ["4.000"]), mRun("≈1.78")]));
  children.push(p("因此不能通过调后级滤波器掩盖该问题，而应回到三角波发生器降低施密特阈值。按目标比例估算：", { indent: 420 }));
  children.push(mathPara([frac(["4.000"], ["7.120"]), mRun("≈0.562,  "), frac(["75"], ["130"]), mRun("≈0.577")]));
  children.push(p("将 R1 从 130 kΩ 调到 75 kΩ 后，阈值比例接近目标修正比例；同时 C1 从 68 nF 增大到 110 nF，用于补偿阈值降低导致的周期缩短。", { indent: 420 }));
  children.push(...imageBlock(figFail));

  children.push(h1("八、AI 辅助与设计思考"));
  children.push(p("AI 主要用于整理任务书检查点、查阅 LM324 与 Sallen-Key 滤波器资料、恢复 Multisim 32 位 COM 工具链、读取元件参数和根据示波器光标读数进行参数推理。最终电路不是由 AI 直接给出，而是根据课程指标、器件资料、理论公式和 Multisim 仿真证据逐步收敛得到。", { indent: 420 }));

  children.push(h1("九、结论"));
  children.push(p("最终电路实现了三角波发生、加法和低通滤波三个功能。XSC1 显示三角波约 4.178 Vpp、周期约 0.206 ms；XSC2 显示混合信号符合加法关系；XSC3 显示滤波输出约 4.977 Vpp，无明显失真。设计满足课程要求。", { indent: 420 }));

  children.push(h1("参考文献"));
  refs.forEach((x, i) => children.push(p(`[${i + 1}] ${x}`, { size: 22, line: 320 })));

  const doc = new Document({
    styles: { default: { document: { run: { font: "宋体", size: 24 } } }, paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, font: "黑体" }, paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 28, bold: true, font: "黑体" }, paragraph: { spacing: { before: 220, after: 100 }, outlineLevel: 1 } },
    ] },
    sections: [{ properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1134, right: 1134, bottom: 1134, left: 1134 } } }, children }],
  });
  fs.writeFileSync(files.docx, await Packer.toBuffer(doc));
}

async function main() {
  fs.writeFileSync(files.md, md, "utf8");
  fs.writeFileSync(files.html, html(md), "utf8");
  await docx();
  for (const f of [files.docx, files.md, files.html]) fs.copyFileSync(f, path.join(outputsDir, path.basename(f)));
  console.log(JSON.stringify(files, null, 2));
}
main().catch((e) => { console.error(e); process.exit(1); });
