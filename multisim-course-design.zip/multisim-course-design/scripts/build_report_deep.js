const fs = require("fs");
const path = require("path");
const {
  AlignmentType,
  BorderStyle,
  Document,
  HeadingLevel,
  ImageRun,
  LevelFormat,
  Packer,
  PageBreak,
  Paragraph,
  Table,
  TableCell,
  TableOfContents,
  TableRow,
  TextRun,
  UnderlineType,
  WidthType,
} = require("docx");

const root = "C:\\Users\\syfdy\\Desktop\\Multisim_课程设计_14500优化版";
const reportDir = path.join(root, "02_报告材料");
const assetsDir = path.join(reportDir, "assets");
const outputsDir = "C:\\Users\\syfdy\\Documents\\Codex\\2026-06-26\\gai\\outputs";
const imageMeta = JSON.parse(fs.readFileSync(path.join(assetsDir, "image_meta.json"), "utf8").replace(/^\uFEFF/, ""));

const outBase = "集成运算放大器的应用_课程设计报告_靳天乐_2023141080190_深化版";
const files = {
  docx: path.join(reportDir, `${outBase}.docx`),
  md: path.join(reportDir, `${outBase}.md`),
  html: path.join(reportDir, `${outBase}.html`),
  logo: path.join(assetsDir, "sichuan_university_logo.png"),
};

const refs = [
  "Texas Instruments, LM324, LM324A, LM224, LM2902 Quadruple Operational Amplifiers datasheet, https://www.ti.com/product/LM324",
  "Texas Instruments, Analysis of the Sallen-Key Architecture, Application Report SLOA024, https://www.ti.com/lit/pdf/sloa024",
  "Texas Instruments, Active Low-Pass Filter Design, Application Report SLOA049, https://www.ti.com/lit/pdf/sloa049",
  "National Instruments, Multisim Oscilloscope documentation, https://www.ni.com/docs/en-US/bundle/multisim/page/topics/oscilloscope.html",
];

const figures = [
  ["fig00_failed_triangle_wave.png", "图0  初始版本三角波幅度偏大的失败现象", "旧版 XSC1 光标读数约为 +3.923 V 与 -3.197 V，峰峰值约 7.120 V，明显超过题目要求的 4 Vpp；同时顶部和底部有轻微圆滑，说明不能只凭最终滤波输出判断电路合格。", 560],
  ["fig02_overall_circuit_wide.png", "图1  triangle_fixed 版整体电路", "整体电路分为三角波发生器、加法器、二阶有源低通滤波器和末级观察缓冲。图中 XSC1、XSC2、XSC3 分别用于验证前级源信号、加法输出和滤波输出。", 560],
  ["fig03_triangle_unit.png", "图2  三角波发生器局部电路", "U1A 与反馈网络构成比较/施密特触发环节，D1/D2 稳定输出幅度；U1B 与 C1 构成积分器，将限幅后的方波积分成三角波。", 520],
  ["fig01_xsc1_triangle_wave.png", "图3  XSC1 三角波输出测量", "光标读数为 +2.264 V 与 -1.913 V，峰峰值约 4.178 V；峰到谷时间约 103.290 us，因此完整周期约 0.206 ms，接近 5 kHz。", 560],
  ["fig06_adder_unit.png", "图4  加法电路局部", "U1C 及 R5/R6/R7/R8 实现比例叠加，使 0.1 V 的 500 Hz 正弦分量放大到与三角波相当的量级。", 460],
  ["fig04_xsc2_adder_output.png", "图5  XSC2 加法输出 ui2", "输出呈现 500 Hz 正弦包络上叠加 5 kHz 三角波纹，符合 ui2=20ui1+uo1 的信号组成。", 560],
  ["fig09_filter_unit.png", "图6  二阶有源低通滤波器局部", "R10、R11、C2、C4 决定截止频率，R12、R13 决定非反相通带增益。该级用于保留 500 Hz 正弦并衰减 5 kHz 三角波分量。", 500],
  ["fig07_xsc3_filter_output.png", "图7  XSC3 滤波输出 uo2", "输出峰峰值约 4.977 V，接近 5 Vpp；波形平滑，没有明显削顶，说明滤波器对高频三角波分量抑制有效。", 560],
  ["fig05_overall_circuit_alt.png", "图8  仿真运行状态记录", "记录最终工程在 Multisim 中的运行状态和示波器布置，便于说明本报告所有波形均来自同一修正版工程。", 560],
  ["fig08_overall_circuit_final.png", "图9  最终观察点布置", "XSC1、XSC2、XSC3 构成从源信号到滤波输出的完整证据链，可按课程要求逐级检查。", 560],
];

function run(text, opts = {}) {
  return new TextRun({
    text,
    font: { ascii: opts.asciiFont || "Times New Roman", eastAsia: opts.cnFont || "宋体" },
    size: opts.size || 24,
    bold: opts.bold || false,
    italics: opts.italics || false,
    underline: opts.underline,
    color: opts.color,
  });
}

function para(text, opts = {}) {
  const children = Array.isArray(text) ? text : [run(text, opts)];
  return new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    heading: opts.heading,
    spacing: { before: opts.before ?? 80, after: opts.after ?? 80, line: opts.line ?? 360 },
    indent: opts.indent ? { firstLine: opts.indent } : undefined,
    children,
  });
}

function h1(text) {
  return para(text, { heading: HeadingLevel.HEADING_1, cnFont: "黑体", size: 32, bold: true, before: 280, after: 180 });
}

function h2(text) {
  return para(text, { heading: HeadingLevel.HEADING_2, cnFont: "黑体", size: 28, bold: true, before: 220, after: 120 });
}

function h3(text) {
  return para(text, { heading: HeadingLevel.HEADING_3, cnFont: "黑体", size: 25, bold: true, before: 160, after: 80 });
}

function formula(text) {
  return para(text, { align: AlignmentType.CENTER, asciiFont: "Cambria Math", cnFont: "Cambria Math", size: 24, before: 80, after: 80 });
}

function table(rows, widths) {
  const border = { style: BorderStyle.SINGLE, size: 1, color: "888888" };
  return new Table({
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((row, idx) => new TableRow({
      children: row.map((cell, i) => new TableCell({
        width: { size: widths[i], type: WidthType.DXA },
        borders: { top: border, bottom: border, left: border, right: border },
        margins: { top: 80, bottom: 80, left: 110, right: 110 },
        children: [para(cell, { align: AlignmentType.CENTER, cnFont: idx === 0 ? "黑体" : "宋体", bold: idx === 0, size: 21, before: 20, after: 20, line: 300 })],
      })),
    })),
  });
}

function imageBlock(file, title, note, width) {
  const [w, h] = imageMeta[file];
  const height = Math.round(width * h / w);
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 120, after: 70 },
      children: [new ImageRun({
        type: "png",
        data: fs.readFileSync(path.join(assetsDir, file)),
        transformation: { width, height },
        altText: { title, description: note, name: file },
      })],
    }),
    para(title, { align: AlignmentType.CENTER, cnFont: "黑体", size: 22, bold: true, before: 20, after: 30 }),
    para(`观察与结论：${note}`, { indent: 420, size: 22, before: 20, after: 120, line: 320 }),
  ];
}

function coverField(label, value) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 130, after: 130 },
    children: [
      run(label, { cnFont: "宋体", size: 30 }),
      run("　　", { size: 30 }),
      run(value.padStart(Math.max(value.length, 14), " "), {
        cnFont: "楷体",
        size: 30,
        bold: true,
        underline: { type: UnderlineType.SINGLE },
      }),
    ],
  });
}

function cover() {
  const [logoW, logoH] = imageMeta["sichuan_university_logo.png"];
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 60, after: 360 },
      children: [new ImageRun({
        type: "png",
        data: fs.readFileSync(files.logo),
        transformation: { width: 130, height: Math.round(130 * logoH / logoW) },
        altText: { title: "四川大学校徽", description: "四川大学校徽", name: "scu-logo" },
      })],
    }),
    coverField("题　　目", "集成运算放大器的应用"),
    coverField("学　　院", "生物医学工程学院"),
    coverField("专　　业", "医学信息工程"),
    coverField("学生姓名", "靳天乐"),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 130, after: 130 },
      children: [
        run("学　　号", { cnFont: "宋体", size: 30 }),
        run("　　", { size: 30 }),
        run("2023141080190", { asciiFont: "Times New Roman", size: 30, bold: true, underline: { type: UnderlineType.SINGLE } }),
        run(" 年级　", { cnFont: "宋体", size: 30 }),
        run("24 级", { cnFont: "楷体", size: 30, bold: true, underline: { type: UnderlineType.SINGLE } }),
      ],
    }),
    para("", { after: 1700 }),
    para("教务处制表", { align: AlignmentType.CENTER, cnFont: "宋体", size: 28 }),
    para("二〇二六年五月二十七日", { align: AlignmentType.CENTER, cnFont: "宋体", size: 28 }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

const md = `# 集成运算放大器的应用课程设计报告（深化版）

学生：靳天乐（2023141080190）  
学院：生物医学工程学院  
专业：医学信息工程  
年级：24级  

## 一、设计任务与指标分解

本课程设计要求使用 LM324 四运放芯片完成三个连续功能：第一，自制振荡器产生 5 kHz、约 4 Vpp 的三角波；第二，将 500 Hz 低频正弦信号与三角波按比例相加；第三，通过多阶低通滤波器滤除三角波频率分量，恢复 500 Hz、约 5 Vpp 的正弦输出。

低频输入为

$$u_{i1}=0.1\\sin(2\\pi\\cdot500t)\\ \\mathrm{V}$$

加法器目标为

$$u_{i2}=20u_{i1}+u_{o1}$$

输出目标为：$u_{o2}$ 是 $500\\ \\mathrm{Hz}$ 正弦波，峰峰值约 $5\\ \\mathrm{V}$，示波器观察无明显失真。

## 二、总体设计思路

本设计采用“先产生高频三角波，再与低频正弦相加，最后选频滤波”的分级结构。这样做的好处是每一级功能明确，可以分别用 XSC1、XSC2、XSC3 检查。如果最终输出异常，可以沿信号链反推问题来源，而不是盲目修改后级增益。

设计时主要参考三类资料：第一，LM324 数据手册，用于确认运放供电范围、输出摆幅和转换速率是否足以支持 5 kHz、4 Vpp 三角波以及 500 Hz、5 Vpp 正弦波；第二，Sallen-Key 有源低通滤波器设计资料，用于确定截止频率、通带增益和 Q 值的计算方法；第三，Multisim 示波器文档和课程任务书，用于确定必须提交哪些波形、如何用光标读出峰峰值与周期。

## 三、初始版本失败原因与优化路线

初始版本的问题不是“完全没有输出”，而是最终正弦输出看起来较好时，前级三角波却不满足课程要求。旧版 XSC1 光标读数约为 +3.923 V 和 -3.197 V，因此

$$V_{pp,old}=3.923-(-3.197)=7.120\\ \\mathrm{V}$$

课程要求三角波约为 +2 V 到 -2 V，即

$$V_{pp,target}=4.000\\ \\mathrm{V}$$

所以旧版幅度约为目标的

$$\\frac{7.120}{4.000}\\approx1.78$$

这说明失败原因主要在三角波发生器，而不是滤波器。若只通过后级滤波器把最终正弦调好，会掩盖前级源信号不合格的问题。因此优化路线确定为：先修三角波幅度和周期，再复查加法输出和滤波输出。

## 四、三角波发生器设计与推导

三角波发生器由施密特触发器和积分器组成。施密特触发器提供正负翻转阈值，积分器把近似方波积分为线性上升和下降的三角波。D1、D2 为 3.9 V 稳压管，用于限制比较器输出幅度，使积分器输入斜率稳定。

积分器基本关系为

$$\\frac{du_o}{dt}\\approx-\\frac{u_{in}}{R_4C_1}$$

因此，三角波幅度主要由施密特触发阈值决定，周期则与阈值、电容和积分输入幅度共同相关。初始版本中测得三角波约 $7.12\\ \\mathrm{Vpp}$，而目标为 $4\\ \\mathrm{Vpp}$。比例为

$$\\frac{4.00}{7.12}\\approx0.562$$

这说明触发阈值需要降低到原来的约 56%。实际修改中将 $R_1$ 从 $130\\ \\mathrm{k\\Omega}$ 降到 $75\\ \\mathrm{k\\Omega}$：

$$\\frac{75}{130}\\approx0.577$$

该比例与目标幅度修正比例接近，因此可将三角波幅度拉回到 4 Vpp 附近。阈值降低会使积分器更早翻转，周期可能变短；为补偿这一点，将 $C_1$ 从 $68\\ \\mathrm{nF}$ 增大到 $110\\ \\mathrm{nF}$：

$$\\frac{110}{68}\\approx1.62$$

这样可以降低积分斜率，保持周期接近 $0.2\\ \\mathrm{ms}$。最终 XSC1 测得 $V_{pp}\\approx4.178\\ \\mathrm{V}$，峰到谷时间约 $103.290\\ \\mu s$，完整周期约 $0.206\\ \\mathrm{ms}$，满足课程要求。

## 五、加法器设计重点

加法器需要实现

$$u_{i2}=20u_{i1}+u_{o1}$$

由于 $u_{i1}$ 峰值只有 $0.1\\ \\mathrm{V}$，若不放大，在与约 $\\pm2\\ \\mathrm{V}$ 的三角波相加时几乎不可见。因此先通过电阻比例使正弦分量获得约 20 倍权重，得到约 $2\\ \\mathrm{V}$ 峰值的低频包络。这样 $20u_{i1}$ 与 $u_{o1}$ 在幅度量级上相当，XSC2 上能看到低频正弦包络叠加高频三角波纹。

本级设计重点不是让输出变得光滑，而是准确形成待滤波的混合信号。XSC2 的波形越能体现“500 Hz 包络 + 5 kHz 高频分量”，越说明加法器功能正确。

## 六、低通滤波器计算与参数优化

滤波器采用二阶有源 Sallen-Key 低通结构。最终参数为

$$R_{10}=R_{11}=14.5\\ \\mathrm{k\\Omega},\\quad C_2=C_4=22\\ \\mathrm{nF}$$

$$R_{12}=22\\ \\mathrm{k\\Omega},\\quad R_{13}=14.5\\ \\mathrm{k\\Omega}$$

非反相通带增益为

$$K=1+\\frac{R_{13}}{R_{12}}=1+\\frac{14.5}{22}\\approx1.659$$

截止频率估算为

$$f_c=\\frac{1}{2\\pi\\sqrt{R_{10}R_{11}C_2C_4}}$$

代入数值：

$$f_c\\approx\\frac{1}{2\\pi\\times14.5\\times10^3\\times22\\times10^{-9}}\\approx499\\ \\mathrm{Hz}$$

这使 500 Hz 目标信号处在滤波器通带边缘附近，可在获得一定增益的同时抑制 5 kHz 高频分量。按二阶低通模型估计，品质因数约为

$$Q\\approx0.746$$

这个 Q 值没有过高，因此不会造成明显尖峰振荡；同时又能在 500 Hz 附近提供足够输出幅度。最终 XSC3 测得 $V_{pp}\\approx4.977\\ \\mathrm{V}$，与 5 Vpp 目标非常接近。

## 七、参数优化过程

本设计不是一次得到最终参数，而是经过“观察现象—定位问题—理论估算—候选修改—仿真验证”的循环得到。关键优化过程如下：

| 阶段 | 观察到的问题 | 推理 | 修改 |
|---|---|---|---|
| 初始方案 | 滤波输出较好，但三角波约 7.12 Vpp | 前级源信号不符合课程要求，不能只看最终输出 | 回到 XSC1 检查三角波单元，并保留失败图作为证据 |
| 三角波修正 | 幅度过大，周期接近 | 主要是施密特阈值过高，周期需同步补偿 | R1: 130kΩ -> 75kΩ；C1: 68nF -> 110nF |
| 后级复查 | 三角波修正后担心影响滤波输出 | 三角波幅度降低会减少 5 kHz 残留，低频正弦通路基本不变 | 保持滤波器参数不变，复查 XSC3 |
| 最终确认 | uo2 约 4.977 Vpp | 幅度接近 5 Vpp，且波形无明显失真 | 接受 triangle_fixed 版 |

## 八、仿真图与测量结果

${figures.map(([file, title, note]) => `![${title}](assets/${file})\n\n${note}`).join("\n\n")}

## 九、输出波形差异分析

$u_{o2}$ 与原始 $u_{i1}$ 不完全相同，原因主要有三点。第一，$u_{i1}$ 在加法器中被按 20 倍权重放大，所以输出幅度远大于原始 0.1 V 峰值输入。第二，滤波器自身有通带增益 $K\\approx1.659$，并且在 500 Hz 附近存在幅频响应变化。第三，二阶有源滤波器不是理想滤波器，会带来有限相移和少量残余高频成分。因此，$u_{o2}$ 的频率应与 $u_{i1}$ 相同，但幅值和相位不必完全相同。

## 十、电路优缺点与改进方向

优点：各级功能清晰，全部核心模块均由 LM324 实现；示波器检查点覆盖前级、中间级和最终输出；修正版同时满足三角波幅度、周期和滤波输出幅度要求。

不足：三角波幅度对施密特阈值和稳压管模型敏感；滤波输出幅值依赖电阻电容精度；如果实际搭建，LM324 的输入失调、电容误差、稳压管动态电阻都会造成偏差。

改进方向：实际电路可将关键电阻改为可调电阻，例如三角波阈值电阻和滤波器增益电阻；也可增加频谱分析或瞬态数据导出，用定量谐波失真指标替代单纯目测。

## 十一、AI 辅助设计说明

AI 在本次设计中主要承担四类工作：整理课程要求、查找 LM324 和 Sallen-Key 滤波器资料、恢复 Multisim 32 位 COM 自动化工具链、根据示波器光标读数进行参数推理。关键贡献是发现“最终正弦看起来可以，但三角波源信号不合格”的问题，并根据幅度比例推导出 R1/C1 的修改方向。这个过程体现了本次设计的基本思路：不是为了让某一张波形好看而调参，而是把课程指标拆成逐级可验证的约束，按证据逐项修正。最终判断仍以 Multisim 仿真和人工光标读数为准，AI 只作为辅助分析工具。

## 参考文献

${refs.map((r, i) => `[${i + 1}] ${r}`).join("\n")}
`;

function htmlContent(markdown) {
  let html = markdown
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/^# (.*)$/gm, "<h1>$1</h1>")
    .replace(/^## (.*)$/gm, "<h2>$1</h2>")
    .replace(/!\[(.*?)\]\((.*?)\)/g, '<figure><img src="$2" alt="$1"><figcaption>$1</figcaption></figure>')
    .replace(/\n\n/g, "</p><p>")
    .replace(/<p><h/g, "<h")
    .replace(/<\/h([12])><\/p>/g, "</h$1>")
    .replace(/<p><figure>/g, "<figure>")
    .replace(/<\/figure><\/p>/g, "</figure>");
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>集成运算放大器的应用课程设计报告（深化版）</title><script>window.MathJax={tex:{inlineMath:[['$','$'],['\\\\(','\\\\)']]},svg:{fontCache:'global'}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script><style>body{font-family:"Noto Serif CJK SC","SimSun",serif;max-width:900px;margin:40px auto;line-height:1.8;color:#111}h1,h2{font-family:"SimHei","Microsoft YaHei",sans-serif}h1{text-align:center}img{max-width:100%;border:1px solid #ddd}figure{text-align:center;margin:28px 0}figcaption{font-weight:700;margin-top:8px}p{text-indent:2em}table{border-collapse:collapse;width:100%}td,th{border:1px solid #888;padding:6px}</style></head><body><p>${html}</p></body></html>`;
}

function addSectionFromMd(children) {
  children.push(h1("一、设计任务与指标分解"));
  children.push(para("本课程设计要求使用 LM324 四运放芯片完成三个连续功能：自制 5 kHz、约 4 Vpp 的三角波；将 500 Hz 正弦信号与三角波按比例相加；通过多阶低通滤波器滤除三角波频率分量，恢复 500 Hz、约 5 Vpp 的正弦输出。", { indent: 420 }));
  children.push(formula("u_i1 = 0.1 sin(2π·500t) V"));
  children.push(formula("u_i2 = 20u_i1 + u_o1"));
  children.push(table([
    ["检查对象", "课程目标", "最终结果"],
    ["三角波 uo1", "5 kHz，约 4 Vpp", "约 4.178 Vpp，周期约 0.206 ms"],
    ["加法输出 ui2", "20ui1+uo1", "500 Hz 包络叠加 5 kHz 三角波"],
    ["滤波输出 uo2", "500 Hz，约 5 Vpp", "约 4.977 Vpp，无明显失真"],
  ], [2200, 3400, 3400]));

  children.push(h1("二、总体设计思路"));
  children.push(para("本设计采用“先产生高频三角波，再与低频正弦相加，最后选频滤波”的分级结构。这样每一级功能明确，可以分别用 XSC1、XSC2、XSC3 检查。如果最终输出异常，可以沿信号链反推问题来源，而不是盲目修改后级增益。", { indent: 420 }));
  children.push(para("设计时主要参考三类资料：LM324 数据手册用于确认运放动态能力和供电条件；Sallen-Key 有源低通滤波器资料用于确定截止频率、通带增益和 Q 值；课程任务书与 Multisim 示波器文档用于确定必须提交的截图和光标读数。", { indent: 420 }));

  children.push(h1("三、初始版本失败原因与优化路线"));
  children.push(para("初始版本不是完全没有输出，而是最终正弦输出较好时，前级三角波却不满足课程要求。旧版 XSC1 光标读数约为 +3.923 V 和 -3.197 V，峰峰值约 7.120 V，明显大于课程要求的 4 Vpp。", { indent: 420 }));
  children.push(formula("V_pp,old = 3.923 - (-3.197) = 7.120 V"));
  children.push(formula("7.120 / 4.000 ≈ 1.78"));
  children.push(para("这说明失败原因主要在三角波发生器，而不是滤波器。若只调后级滤波器，可能会让最终输出看起来更好，但前级源信号仍不合格。因此优化路线确定为：先修三角波幅度和周期，再复查加法器和滤波器输出。", { indent: 420 }));
  children.push(...imageBlock("fig00_failed_triangle_wave.png", "图0  初始版本三角波幅度偏大的失败现象", "旧版三角波约 7.120 Vpp，超过课程要求 4 Vpp，是本次参数优化的主要起点。", 560));

  children.push(h1("四、三角波发生器设计与推导"));
  children.push(para("三角波发生器由施密特触发器和积分器组成。施密特触发器提供正负翻转阈值，积分器把近似方波积分为线性上升和下降的三角波。D1、D2 为 3.9 V 稳压管，用于限制比较器输出幅度，使积分器输入斜率稳定。", { indent: 420 }));
  children.push(formula("du_o/dt ≈ -u_in/(R_4 C_1)"));
  children.push(para("初始版本中测得三角波约 7.12 Vpp，而目标为 4 Vpp，因此触发阈值应降到原来的约 4.00/7.12≈0.562。实际将 R1 从 130 kΩ 降到 75 kΩ，比例 75/130≈0.577，与目标修正比例接近。阈值降低后周期会缩短，所以将 C1 从 68 nF 增大到 110 nF，使积分速度下降并补偿周期。", { indent: 420 }));
  children.push(formula("4.00/7.12 ≈ 0.562,  75/130 ≈ 0.577,  110/68 ≈ 1.62"));

  children.push(h1("五、加法器设计重点"));
  children.push(para("加法器需要实现 ui2=20ui1+uo1。由于 ui1 峰值只有 0.1 V，若不放大，在与约 ±2 V 的三角波相加时几乎不可见。因此通过电阻比例使正弦分量获得约 20 倍权重，得到约 2 V 峰值的低频包络。该级的重点不是让输出光滑，而是准确形成待滤波的混合信号。", { indent: 420 }));

  children.push(h1("六、低通滤波器计算与参数优化"));
  children.push(para("滤波器采用二阶有源 Sallen-Key 低通结构。最终参数为 R10=R11=14.5 kΩ，C2=C4=22 nF，R12=22 kΩ，R13=14.5 kΩ。R10、R11、C2、C4 决定截止频率，R12、R13 决定非反相增益。", { indent: 420 }));
  children.push(formula("K = 1 + R13/R12 = 1 + 14.5/22 ≈ 1.659"));
  children.push(formula("f_c = 1/(2π√(R10 R11 C2 C4)) ≈ 499 Hz"));
  children.push(para("该截止频率接近 500 Hz，使目标信号处在通带边缘附近；同时 5 kHz 是目标频率的 10 倍，二阶低通可以显著压低三角波残留。估算 Q≈0.746，未形成过高尖峰，因此输出正弦较平滑。", { indent: 420 }));

  children.push(h1("七、参数优化过程"));
  children.push(table([
    ["阶段", "观察到的问题", "推理", "修改"],
    ["初始方案", "滤波输出较好，但三角波约 7.12 Vpp", "前级源信号不符合课程要求", "回到 XSC1 检查并保留失败图"],
    ["三角波修正", "幅度过大，周期接近", "施密特阈值过高，周期需补偿", "R1:130kΩ->75kΩ；C1:68nF->110nF"],
    ["后级复查", "担心影响滤波输出", "低频正弦通路基本不变，高频残留会减少", "滤波器参数保持不变"],
    ["最终确认", "uo2 约 4.977 Vpp", "接近 5 Vpp 且无明显失真", "接受 triangle_fixed 版"],
  ], [1500, 2600, 2900, 2500]));

  children.push(h1("八、仿真图与测量结果"));
  for (const fig of figures) children.push(...imageBlock(...fig));

  children.push(h1("九、输出波形差异分析"));
  children.push(para("uo2 与原始 ui1 不完全相同，主要因为 ui1 在加法器中被按 20 倍权重放大，滤波器本身也有通带增益 K≈1.659，并且二阶有源滤波器会带来有限相移和幅频响应变化。因此 uo2 的频率应与 ui1 相同，但幅值和相位不必完全相同。", { indent: 420 }));

  children.push(h1("十、电路优缺点与改进方向"));
  children.push(para("优点是各级功能清晰，全部核心模块均由 LM324 实现，且示波器检查点覆盖前级、中间级和最终输出。缺点是三角波幅度对施密特阈值和稳压管模型敏感，滤波输出幅值依赖电阻电容精度。实际搭建时可把关键电阻改为可调电阻，也可增加频谱分析或瞬态数据导出，用更定量的谐波失真指标评价。", { indent: 420 }));

  children.push(h1("十一、AI 辅助设计说明"));
  children.push(para("AI 在本次设计中主要用于整理课程要求、查找 LM324 和 Sallen-Key 滤波器资料、恢复 Multisim 32 位 COM 自动化工具链、读取元件参数和根据示波器光标读数进行参数推理。关键作用是发现“最终正弦看起来可以，但三角波源信号不合格”的问题，并根据幅度比例推导出 R1/C1 的修改方向。这个过程不是简单让波形好看，而是把课程指标拆成逐级可验证的约束，并按证据逐项修正。最终判断仍以 Multisim 仿真和人工光标读数为准。", { indent: 420 }));

  children.push(h1("参考文献"));
  refs.forEach((r, i) => children.push(para(`[${i + 1}] ${r}`, { size: 22, line: 320 })));
}

async function buildDocx() {
  const children = [];
  children.push(...cover());
  children.push(para("目  录", { align: AlignmentType.CENTER, cnFont: "黑体", size: 34, bold: true }));
  children.push(new TableOfContents("目录", { hyperlink: true, headingStyleRange: "1-3" }));
  children.push(new Paragraph({ children: [new PageBreak()] }));
  addSectionFromMd(children);
  const doc = new Document({
    styles: {
      default: { document: { run: { font: "宋体", size: 24 } } },
      paragraphStyles: [
        { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, font: "黑体" }, paragraph: { spacing: { before: 280, after: 180 }, outlineLevel: 0 } },
        { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 28, bold: true, font: "黑体" }, paragraph: { spacing: { before: 220, after: 120 }, outlineLevel: 1 } },
        { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 25, bold: true, font: "黑体" }, paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 2 } },
      ],
    },
    numbering: { config: [{ reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }] },
    sections: [{ properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1134, right: 1134, bottom: 1134, left: 1134 } } }, children }],
  });
  fs.writeFileSync(files.docx, await Packer.toBuffer(doc));
}

async function main() {
  fs.mkdirSync(reportDir, { recursive: true });
  fs.mkdirSync(outputsDir, { recursive: true });
  fs.writeFileSync(files.md, md, "utf8");
  fs.writeFileSync(files.html, htmlContent(md), "utf8");
  await buildDocx();
  for (const f of [files.docx, files.md, files.html]) fs.copyFileSync(f, path.join(outputsDir, path.basename(f)));
  console.log(JSON.stringify(files, null, 2));
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
