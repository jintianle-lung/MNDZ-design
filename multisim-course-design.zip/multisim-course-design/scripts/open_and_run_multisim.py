from __future__ import annotations

import argparse
import json
import time

import win32com.client


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("path")
    parser.add_argument("--seconds", type=float, default=0.25)
    parser.add_argument("--settle", type=float, default=2.0)
    args = parser.parse_args()

    app = win32com.client.gencache.EnsureDispatch("MultisimInterface.MultisimApp")
    app.Connect()
    doc = app.OpenFile(args.path)
    doc.RunSimulation(float(args.seconds), False)
    time.sleep(args.settle)
    payload = {
        "path": args.path,
        "version": app.VersionInfo,
        "last_error": app.LastErrorMessage,
        "simulation_state": getattr(doc, "SimulationState", None),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
