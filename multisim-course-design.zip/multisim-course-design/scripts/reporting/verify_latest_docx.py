import json
import zipfile
from pathlib import Path

outputs = Path(r"C:\Users\syfdy\Documents\Codex\2026-06-26\gai\outputs")
docx_files = [p for p in outputs.glob("*.docx") if not p.name.startswith("~$")]
target = max(docx_files, key=lambda p: p.stat().st_mtime)

with zipfile.ZipFile(target) as archive:
    xml = archive.read("word/document.xml").decode("utf-8")
    media = [name for name in archive.namelist() if name.startswith("word/media/")]

checks = {
    "path": str(target),
    "exists": target.exists(),
    "size": target.stat().st_size,
    "math_objects": xml.count("<m:oMath"),
    "images": len(media),
    "has_cover_title": "集成运算放大器的应用" in xml,
    "has_task_chapter": "一、设计任务与要求" in xml,
    "has_parameter_chapter": "二、参数设计" in xml,
    "has_simulation_chapter": "三、仿真验证及测量" in xml,
    "has_summary_chapter": "四、总结" in xml,
    "has_failed_in_discussion": "旧版电路曾出现三角波幅度偏大的问题" in xml,
    "has_ai_statement": "AI 辅助主要用于整理课程要求" in xml,
    "has_formula_text_leftover": "$$" in xml,
    "has_core_values": all(
        value in xml
        for value in ["4.178 V", "0.206 ms", "4.977 Vpp", "498.9 Hz", "0.746"]
    ),
}

print(json.dumps(checks, ensure_ascii=False, indent=2))
