$outputs = "C:\Users\syfdy\Documents\Codex\2026-06-26\gai\outputs"
$doc = Get-ChildItem -LiteralPath $outputs -Filter "*.docx" |
  Where-Object { -not $_.Name.StartsWith("~$") } |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 1

$word = $null
try {
  $word = New-Object -ComObject Word.Application
  $word.Visible = $false
  $document = $word.Documents.Open($doc.FullName, $false, $true)
  $pages = $document.ComputeStatistics(2)
  $paragraphs = $document.Paragraphs.Count
  $document.Close($false)
  [pscustomobject]@{
    WordOpen = $true
    File = $doc.FullName
    Pages = $pages
    Paragraphs = $paragraphs
  } | ConvertTo-Json -Compress
} catch {
  [pscustomobject]@{
    WordOpen = $false
    File = if ($doc) { $doc.FullName } else { "" }
    Error = $_.Exception.Message
  } | ConvertTo-Json -Compress
} finally {
  if ($word) {
    $word.Quit()
  }
}
