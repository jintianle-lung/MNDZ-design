# 课程设计报告生成脚本

本目录保存本次 Multisim 课程设计报告的可复现生成流程。

## 脚本说明

- `build_report_polished.js`：生成 DOCX、Markdown、HTML 三种报告版本。DOCX 使用 Word 原生公式对象，Markdown/HTML 保留 LaTeX 公式。
- `verify_latest_docx.py`：检查最新 DOCX 是否包含章节、公式对象、图片、核心测量值和 AI 辅助说明。
- `word_open_latest.ps1`：调用本机 Word COM 打开最新 DOCX，确认文件可正常加载。

## 使用方法

```powershell
set NODE_PATH=C:\Users\syfdy\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules
C:\Users\syfdy\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe scripts\reporting\build_report_polished.js

C:\Users\syfdy\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe scripts\reporting\verify_latest_docx.py
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\reporting\word_open_latest.ps1
```

脚本默认读取 `C:\Users\syfdy\Desktop\Multisim_课程设计_14500优化版\02_报告材料\assets` 中的截图与校徽，并把最终文件复制到 Codex `outputs` 目录。
