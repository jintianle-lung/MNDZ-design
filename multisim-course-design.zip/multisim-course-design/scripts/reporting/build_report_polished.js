const fs = require("fs");
const path = require("path");
const {
  AlignmentType,
  BorderStyle,
  Document,
  HeadingLevel,
  ImageRun,
  Math: DocxMath,
  MathFraction,
  MathRadical,
  MathRun,
  MathSubScript,
  Packer,
  PageBreak,
  Paragraph,
  Table,
  TableCell,
  TableOfContents,
  TableRow,
  TextRun,
  UnderlineType,
  WidthType,
} = require("docx");

const projectRoot = "C:\\Users\\syfdy\\Desktop\\Multisim_课程设计_14500优化版";
const reportDir = path.join(projectRoot, "02_报告材料");
const assetsDir = path.join(reportDir, "assets");
const outputsDir = "C:\\Users\\syfdy\\Documents\\Codex\\2026-06-26\\gai\\outputs";
const outBase = "集成运算放大器的应用_课程设计报告_靳天乐_2023141080190_规范优化终版";
const imageMeta = JSON.parse(fs.readFileSync(path.join(assetsDir, "image_meta.json"), "utf8").replace(/^\uFEFF/, ""));

const files = {
  docx: path.join(reportDir, `${outBase}.docx`),
  md: path.join(reportDir, `${outBase}.md`),
  html: path.join(reportDir, `${outBase}.html`),
  logo: path.join(assetsDir, "sichuan_university_logo.png"),
};

const figs = {
  overall: ["fig02_overall_circuit_wide.png", "图1  最终整体电路", "整体电路由三角波产生器、加法器、二阶有源低通滤波器和三级示波器观察点组成。"],
  triCircuit: ["fig03_triangle_unit.png", "图2  三角波产生电路", "U1A 构成比较/施密特触发环节，D1/D2 提供限幅参考，U1B 与 C1 构成积分器。"],
  triWave: ["fig01_xsc1_triangle_wave.png", "图3  三角波输出 uo1", "XSC1 测得约 +2.264 V 到 -1.913 V，峰峰值约 4.178 V；峰到谷约 103.290 us，完整周期约 0.206 ms。"],
  addCircuit: ["fig06_adder_unit.png", "图4  加法电路", "该级实现 ui2=20ui1+uo1，使低频正弦分量与高频三角波同量级叠加。"],
  addWave: ["fig04_xsc2_adder_output.png", "图5  加法输出 ui2", "XSC2 可见 500 Hz 正弦包络上叠加约 5 kHz 三角波纹，符合加法器目标。"],
  filterCircuit: ["fig09_filter_unit.png", "图6  多阶低通滤波电路", "R10、R11、C2、C4 决定截止频率，R12、R13 设置非反相通带增益。"],
  filterWave: ["fig07_xsc3_filter_output.png", "图7  滤波输出 uo2", "XSC3 输出约 4.977 Vpp，接近 5 Vpp，波形平滑且无明显削顶失真。"],
  points: ["fig08_overall_circuit_final.png", "图8  整体电路及观察点", "XSC1、XSC2、XSC3 分别验证三角波、加法混合信号和最终滤波输出，形成逐级证据链。"],
  failed: ["fig00_failed_triangle_wave.png", "图9  旧版三角波幅度偏大", "旧版三角波约 +3.923 V 到 -3.197 V，峰峰值约 7.120 V，明显超过 4 Vpp 目标。"],
};

const references = [
  "Texas Instruments. LM324, LM324A, LM224, LM2902 Quadruple Operational Amplifiers Datasheet. https://www.ti.com/product/LM324",
  "Texas Instruments. Analysis of the Sallen-Key Architecture, Application Report SLOA024. https://www.ti.com/lit/pdf/sloa024",
  "Texas Instruments. Active Low-Pass Filter Design, Application Report SLOA049. https://www.ti.com/lit/pdf/sloa049",
  "National Instruments. Multisim Oscilloscope Documentation. https://www.ni.com/docs/en-US/bundle/multisim/page/topics/oscilloscope.html",
];

function textRun(text, opts = {}) {
  return new TextRun({
    text,
    font: { ascii: opts.asciiFont || "Times New Roman", eastAsia: opts.cnFont || "宋体" },
    size: opts.size || 24,
    bold: !!opts.bold,
    italics: !!opts.italics,
    underline: opts.underline,
  });
}

function paragraph(content, opts = {}) {
  return new Paragraph({
    heading: opts.heading,
    alignment: opts.align || AlignmentType.LEFT,
    spacing: { before: opts.before ?? 80, after: opts.after ?? 80, line: opts.line ?? 360 },
    indent: opts.indent ? { firstLine: opts.indent } : undefined,
    children: Array.isArray(content) ? content : [textRun(content, opts)],
  });
}

const h1 = (title) => paragraph(title, { heading: HeadingLevel.HEADING_1, cnFont: "黑体", size: 32, bold: true, before: 260, after: 150 });
const h2 = (title) => paragraph(title, { heading: HeadingLevel.HEADING_2, cnFont: "黑体", size: 27, bold: true, before: 180, after: 90 });

function m(text) {
  return new MathRun(text);
}

function sub(base, subscript) {
  return new MathSubScript({ children: [m(base)], subScript: [m(subscript)] });
}

function frac(numerator, denominator) {
  return new MathFraction({
    numerator: Array.isArray(numerator) ? numerator : [m(numerator)],
    denominator: Array.isArray(denominator) ? denominator : [m(denominator)],
  });
}

function sqrt(children) {
  return new MathRadical({ children });
}

function equation(children) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 90, after: 90 },
    children: [new DocxMath({ children })],
  });
}

function table(rows, widths) {
  const border = { style: BorderStyle.SINGLE, size: 1, color: "888888" };
  return new Table({
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((row, rowIndex) => new TableRow({
      children: row.map((cell, colIndex) => new TableCell({
        width: { size: widths[colIndex], type: WidthType.DXA },
        borders: { top: border, bottom: border, left: border, right: border },
        margins: { top: 80, bottom: 80, left: 100, right: 100 },
        children: [paragraph(cell, {
          align: AlignmentType.CENTER,
          cnFont: rowIndex === 0 ? "黑体" : "宋体",
          bold: rowIndex === 0,
          size: 21,
          line: 300,
          before: 20,
          after: 20,
        })],
      })),
    })),
  });
}

function imageBlock([file, title, note], width = 540) {
  const [w, h] = imageMeta[file];
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 110, after: 50 },
      children: [new ImageRun({
        type: "png",
        data: fs.readFileSync(path.join(assetsDir, file)),
        transformation: { width, height: Math.round(width * h / w) },
        altText: { title, description: note, name: file },
      })],
    }),
    paragraph(title, { align: AlignmentType.CENTER, cnFont: "黑体", bold: true, size: 22, before: 20, after: 30 }),
    paragraph(`说明：${note}`, { indent: 420, size: 22, line: 320, before: 20, after: 90 }),
  ];
}

function cover() {
  const [logoW, logoH] = imageMeta["sichuan_university_logo.png"];
  const field = (label, value) => new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 130, after: 130 },
    children: [
      textRun(label, { size: 30, cnFont: "宋体" }),
      textRun("    ", { size: 30 }),
      textRun(value, { cnFont: "楷体", size: 30, bold: true, underline: { type: UnderlineType.SINGLE } }),
    ],
  });

  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 60, after: 360 },
      children: [new ImageRun({
        type: "png",
        data: fs.readFileSync(files.logo),
        transformation: { width: 130, height: Math.round(130 * logoH / logoW) },
        altText: { title: "四川大学校徽", description: "四川大学校徽", name: "scu-logo" },
      })],
    }),
    field("题    目", "集成运算放大器的应用"),
    field("学    院", "生物医学工程学院"),
    field("专    业", "医学信息工程"),
    field("学生姓名", "靳天乐"),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 130, after: 130 },
      children: [
        textRun("学    号", { size: 30 }),
        textRun("    ", { size: 30 }),
        textRun("2023141080190", { size: 30, bold: true, underline: { type: UnderlineType.SINGLE } }),
        textRun("   年级   ", { size: 30 }),
        textRun("24级", { cnFont: "楷体", size: 30, bold: true, underline: { type: UnderlineType.SINGLE } }),
      ],
    }),
    paragraph("", { after: 1700 }),
    paragraph("教务处制表", { align: AlignmentType.CENTER, size: 28 }),
    paragraph("二〇二六年五月二十七日", { align: AlignmentType.CENTER, size: 28 }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function buildMarkdown() {
  return `# 集成运算放大器的应用课程设计报告（规范优化终版）

## 一、设计任务与要求

本课程设计要求使用集成运算放大器完成三角波产生、加法运算和多阶低通滤波，并通过 Multisim 仿真验证各级波形。设计主线不是直接拼接模块，而是先把任务拆成“产生可控高频三角波、按比例叠加低频正弦、滤除高频分量得到规定正弦输出”三个环节，再分别确定参数。

输入低频信号为：

$$u_{i1}=0.1\\sin(2\\pi\\cdot500t)\\ \\mathrm{V}$$

加法级目标为：

$$u_{i2}=20u_{i1}+u_{o1}$$

最终输出要求为 500 Hz、约 5 Vpp 的正弦波，且波形无明显削顶、畸变或高频纹波。设计参考了 LM324 运算放大器数据手册、Sallen-Key 有源低通滤波器设计资料和 Multisim 示波器测量方法。

## 二、参数设计

### 2.1 三角波产生电路

三角波产生电路采用“施密特触发器 + 积分器”的经典结构。施密特触发器提供正负翻转阈值，积分器把近似方波电压转换成线性上升和下降的斜坡。积分器基本关系为：

$$\\frac{du_o}{dt}\\approx-\\frac{u_{in}}{R_4C_1}$$

因此，三角波幅度主要由比较器阈值和限幅网络决定，周期则由积分电阻电容时间常数和阈值跨度共同决定。调试时若只改变阈值电阻，幅度会变化，但周期也会随翻转点改变而漂移，所以本设计采用“先修正幅度，再用积分电容补偿周期”的思路。最终选择：

$$R_1=75\\ \\mathrm{k\\Omega},\\quad C_1=110\\ \\mathrm{nF}$$

仿真结果为：

$$V_{pp}(u_{o1})=2.264-(-1.913)\\approx4.178\\ \\mathrm{V}$$

峰到谷时间约 103.290 us，因此完整周期约：

$$T\\approx2\\times103.290\\ \\mu s=0.206\\ \\mathrm{ms}$$

该结果接近课程要求的 0.2 ms 周期，并把三角波幅度控制在约 4 Vpp 附近。

### 2.2 加法电路

加法器目标是实现：

$$u_{i2}=20u_{i1}+u_{o1}$$

由于低频输入幅值只有 0.1 V，直接送入后级会明显偏小，因此将其放大 20 倍，使低频正弦分量峰值约为 2 V，与三角波约正负 2 V 的量级相当。这样加法输出既能保留 500 Hz 正弦包络，又能叠加可被后级滤除的高频三角波分量。

### 2.3 多阶低通滤波电路

滤波器采用二阶 Sallen-Key 有源低通结构。选择该结构的原因是电路实现简单，运放数量少，并且可以通过电阻电容设定截止频率、通过非反相增益调节输出幅度。最终参数为：

$$R_{10}=R_{11}=14.5\\ \\mathrm{k\\Omega},\\quad C_2=C_4=22\\ \\mathrm{nF}$$

$$R_{12}=22\\ \\mathrm{k\\Omega},\\quad R_{13}=14.5\\ \\mathrm{k\\Omega}$$

通带增益为：

$$K=1+\\frac{R_{13}}{R_{12}}=1+\\frac{14.5}{22}\\approx1.659$$

当两只电阻相等、两只电容相等时，截止频率可估算为：

$$f_c=\\frac{1}{2\\pi\\sqrt{R_{10}R_{11}C_2C_4}}$$

代入数值得：

$$f_c=\\frac{1}{2\\pi\\times14.5\\times10^3\\times22\\times10^{-9}}\\approx498.9\\ \\mathrm{Hz}$$

该截止频率贴近 500 Hz，可保留目标正弦基波，同时对约 5 kHz 三角波分量形成明显衰减。按该 Sallen-Key 参数估算品质因数约为：

$$Q\\approx0.746$$

该值不会导致严重尖峰放大，适合获得较平滑的正弦输出。

## 三、仿真验证及测量

### 3.1 三角波产生电路

![图2  三角波产生电路](assets/fig03_triangle_unit.png)

![图3  三角波输出 uo1](assets/fig01_xsc1_triangle_wave.png)

三角波单元的检查重点是幅值、周期和线性度。XSC1 显示峰峰值约 4.178 V，完整周期约 0.206 ms，说明 R1/C1 调整后同时兼顾了幅度和周期。

### 3.2 加法电路

![图4  加法电路](assets/fig06_adder_unit.png)

![图5  加法输出 ui2](assets/fig04_xsc2_adder_output.png)

加法级检查重点是是否出现 500 Hz 包络，以及三角波纹是否仍被保留。XSC2 波形显示低频包络和高频纹波同时存在，说明加法关系符合设计预期。

### 3.3 多阶低通滤波电路

![图6  多阶低通滤波电路](assets/fig09_filter_unit.png)

![图7  滤波输出 uo2](assets/fig07_xsc3_filter_output.png)

滤波级检查重点是高频三角波分量是否被明显抑制，以及输出是否接近 5 Vpp。XSC3 显示输出约 4.977 Vpp，接近课程要求，波形平滑、无明显削顶。

### 3.4 整体电路及仿真结果

![图1  最终整体电路](assets/fig02_overall_circuit_wide.png)

![图8  整体电路及观察点](assets/fig08_overall_circuit_final.png)

整体电路通过 XSC1、XSC2、XSC3 形成逐级验证：先证明三角波单元达标，再证明加法输出包含目标混合信号，最后证明低通滤波后得到 500 Hz 正弦输出。

## 四、总结

### 输出波形差异分析

最终输出 uo2 与原始输入 ui1 频率相同，但幅值和相位不完全相同。幅值差异来自加法器对 ui1 的 20 倍权重和低通滤波器的通带增益；相位差异来自有源滤波器在截止频率附近的相移。由于本设计把截止频率设置在约 500 Hz，输出幅值接近 5 Vpp，但相位滞后属于正常现象。

### 电路优缺点分析

本电路优点是分级清晰、便于调试，所有核心功能均可由 LM324 运算放大器完成；三处示波器观察点使问题定位更直接。缺点是三角波幅度对施密特触发阈值较敏感，滤波器输出幅度受电阻电容精度和运放带宽影响，若进行实物搭建，关键电阻建议使用精密电阻或可调电阻。

### 调试收获与 AI 辅助说明

旧版电路曾出现三角波幅度偏大的问题，测得约 7.120 Vpp，远高于约 4 Vpp 的目标。该问题没有放在设计主线一开始讨论，而是在调试阶段作为反例分析。根据幅度比例：

$$\\frac{4.000}{7.120}\\approx0.562$$

若原阈值相关电阻取 130 kΩ，则按比例修正可得到：

$$130\\ \\mathrm{k\\Omega}\\times0.562\\approx73.1\\ \\mathrm{k\\Omega}$$

因此选用接近标准值的 75 kΩ：

$$\\frac{75}{130}\\approx0.577$$

仅减小 R1 后周期会随翻转阈值变化而偏离，所以进一步将 C1 从 68 nF 增大到 110 nF，用更大的积分时间常数补偿周期变化。AI 辅助主要用于整理课程要求、检索运放与滤波器资料、恢复 Multisim 自动化工具链、对照波形读数推理参数修正方向，并生成报告和 skill 包；最终判断仍以 Multisim 仿真结果、示波器光标读数和课程指标为准。

![图9  旧版三角波幅度偏大](assets/fig00_failed_triangle_wave.png)

## 参考文献

${references.map((item, index) => `[${index + 1}] ${item}`).join("\n")}
`;
}

function markdownToHtml(markdown) {
  let body = markdown
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/^# (.*)$/gm, "<h1>$1</h1>")
    .replace(/^## (.*)$/gm, "<h2>$1</h2>")
    .replace(/^### (.*)$/gm, "<h3>$1</h3>")
    .replace(/!\[(.*?)\]\((.*?)\)/g, '<figure><img src="$2" alt="$1"><figcaption>$1</figcaption></figure>')
    .replace(/\n\n/g, "</p><p>")
    .replace(/<p><h/g, "<h")
    .replace(/<\/h([123])><\/p>/g, "</h$1>")
    .replace(/<p><figure>/g, "<figure>")
    .replace(/<\/figure><\/p>/g, "</figure>");
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><script>window.MathJax={tex:{inlineMath:[['$','$'],['\\\\(','\\\\)']]},svg:{fontCache:'global'}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script><style>body{font-family:SimSun,serif;max-width:900px;margin:40px auto;line-height:1.8;color:#111}h1,h2,h3{font-family:SimHei,sans-serif}img{max-width:100%;border:1px solid #ddd}figure{text-align:center;margin:26px 0}figcaption{font-family:SimHei,sans-serif;font-weight:700}p{text-indent:2em}</style></head><body><p>${body}</p></body></html>`;
}

function buildDocxChildren() {
  const c = [];
  c.push(...cover());
  c.push(paragraph("目  录", { align: AlignmentType.CENTER, cnFont: "黑体", bold: true, size: 34 }));
  c.push(new TableOfContents("目录", { hyperlink: true, headingStyleRange: "1-3" }));
  c.push(new Paragraph({ children: [new PageBreak()] }));

  c.push(h1("一、设计任务与要求"));
  c.push(paragraph("本课程设计要求使用集成运算放大器完成三角波产生、加法运算和多阶低通滤波，并通过 Multisim 仿真验证各级波形。设计主线是先把任务拆成“产生可控高频三角波、按比例叠加低频正弦、滤除高频分量得到规定正弦输出”三个环节，再分别确定参数。", { indent: 420 }));
  c.push(equation([sub("u", "i1"), m("=0.1sin(2π·500t) V")]));
  c.push(equation([sub("u", "i2"), m("=20"), sub("u", "i1"), m("+"), sub("u", "o1")]));
  c.push(paragraph("最终输出要求为 500 Hz、约 5 Vpp 的正弦波，且波形无明显削顶、畸变或高频纹波。设计参考 LM324 运算放大器数据手册、Sallen-Key 有源低通滤波器设计资料和 Multisim 示波器测量方法。", { indent: 420 }));
  c.push(table([
    ["项目", "设计目标", "最终仿真结果"],
    ["三角波 uo1", "约 5 kHz，约 4 Vpp", "4.178 Vpp，周期约 0.206 ms"],
    ["加法输出 ui2", "20ui1+uo1", "500 Hz 包络叠加约 5 kHz 三角波"],
    ["滤波输出 uo2", "500 Hz，约 5 Vpp", "4.977 Vpp，无明显失真"],
  ], [2300, 3300, 3600]));

  c.push(h1("二、参数设计"));
  c.push(h2("2.1 三角波产生电路"));
  c.push(paragraph("三角波产生电路采用“施密特触发器 + 积分器”的经典结构。施密特触发器提供正负翻转阈值，积分器把近似方波电压转换成线性上升和下降的斜坡。积分器基本关系为：", { indent: 420 }));
  c.push(equation([frac([m("d"), sub("u", "o")], [m("dt")]), m("≈-"), frac([sub("u", "in")], [sub("R", "4"), sub("C", "1")])]));
  c.push(paragraph("因此，三角波幅度主要由比较器阈值和限幅网络决定，周期则由积分电阻电容时间常数和阈值跨度共同决定。调试时若只改变阈值电阻，幅度会变化，但周期也会随翻转点改变而漂移，所以本设计采用“先修正幅度，再用积分电容补偿周期”的思路。", { indent: 420 }));
  c.push(equation([sub("R", "1"), m("=75 kΩ,  "), sub("C", "1"), m("=110 nF")]));
  c.push(equation([sub("V", "pp"), m("("), sub("u", "o1"), m(")=2.264-(-1.913)≈4.178 V")]));
  c.push(equation([m("T≈2×103.290 μs=0.206 ms")]));
  c.push(paragraph("该结果接近课程要求的 0.2 ms 周期，并把三角波幅度控制在约 4 Vpp 附近。", { indent: 420 }));

  c.push(h2("2.2 加法电路"));
  c.push(paragraph("加法器目标是实现低频正弦与三角波的线性叠加。由于低频输入幅值只有 0.1 V，直接送入后级会明显偏小，因此将其放大 20 倍，使低频正弦分量峰值约为 2 V，与三角波约正负 2 V 的量级相当。", { indent: 420 }));
  c.push(equation([sub("u", "i2"), m("=20"), sub("u", "i1"), m("+"), sub("u", "o1")]));
  c.push(equation([m("20×0.1 V=2 V")]));
  c.push(paragraph("这样加法输出既能保留 500 Hz 正弦包络，又能叠加可被后级滤除的高频三角波分量。", { indent: 420 }));

  c.push(h2("2.3 多阶低通滤波电路"));
  c.push(paragraph("滤波器采用二阶 Sallen-Key 有源低通结构。选择该结构的原因是电路实现简单，运放数量少，并且可以通过电阻电容设定截止频率、通过非反相增益调节输出幅度。最终参数如下。", { indent: 420 }));
  c.push(table([
    ["参数", "取值", "作用"],
    ["R10、R11", "14.5 kΩ", "决定滤波器截止频率"],
    ["C2、C4", "22 nF", "决定滤波器截止频率"],
    ["R12", "22 kΩ", "与 R13 共同设置通带增益"],
    ["R13", "14.5 kΩ", "与 R12 共同设置通带增益"],
  ], [2200, 2600, 4400]));
  c.push(equation([m("K=1+"), frac([sub("R", "13")], [sub("R", "12")]), m("=1+14.5/22≈1.659")]));
  c.push(equation([sub("f", "c"), m("="), frac([m("1")], [m("2π"), sqrt([sub("R", "10"), sub("R", "11"), sub("C", "2"), sub("C", "4")])])]));
  c.push(equation([sub("f", "c"), m("="), frac([m("1")], [m("2π×14.5×10³×22×10⁻⁹")]), m("≈498.9 Hz")]));
  c.push(equation([m("Q≈0.746")]));
  c.push(paragraph("该截止频率贴近 500 Hz，可保留目标正弦基波，同时对约 5 kHz 三角波分量形成明显衰减。品质因数约 0.746，不会造成严重尖峰放大，适合获得较平滑的正弦输出。", { indent: 420 }));

  c.push(h1("三、仿真验证及测量"));
  c.push(h2("3.1 三角波产生电路"));
  c.push(...imageBlock(figs.triCircuit, 500));
  c.push(...imageBlock(figs.triWave));
  c.push(paragraph("三角波单元的检查重点是幅值、周期和线性度。XSC1 显示峰峰值约 4.178 V，完整周期约 0.206 ms，说明 R1/C1 调整后同时兼顾了幅度和周期。", { indent: 420 }));
  c.push(h2("3.2 加法电路"));
  c.push(...imageBlock(figs.addCircuit, 460));
  c.push(...imageBlock(figs.addWave));
  c.push(paragraph("加法级检查重点是是否出现 500 Hz 包络，以及三角波纹是否仍被保留。XSC2 波形显示低频包络和高频纹波同时存在，说明加法关系符合设计预期。", { indent: 420 }));
  c.push(h2("3.3 多阶低通滤波电路"));
  c.push(...imageBlock(figs.filterCircuit, 500));
  c.push(...imageBlock(figs.filterWave));
  c.push(paragraph("滤波级检查重点是高频三角波分量是否被明显抑制，以及输出是否接近 5 Vpp。XSC3 显示输出约 4.977 Vpp，接近课程要求，波形平滑、无明显削顶。", { indent: 420 }));
  c.push(h2("3.4 整体电路及仿真结果"));
  c.push(...imageBlock(figs.overall));
  c.push(...imageBlock(figs.points));
  c.push(paragraph("整体电路通过 XSC1、XSC2、XSC3 形成逐级验证：先证明三角波单元达标，再证明加法输出包含目标混合信号，最后证明低通滤波后得到 500 Hz 正弦输出。", { indent: 420 }));

  c.push(h1("四、总结"));
  c.push(h2("输出波形差异分析"));
  c.push(paragraph("最终输出 uo2 与原始输入 ui1 频率相同，但幅值和相位不完全相同。幅值差异来自加法器对 ui1 的 20 倍权重和低通滤波器的通带增益；相位差异来自有源滤波器在截止频率附近的相移。由于本设计把截止频率设置在约 500 Hz，输出幅值接近 5 Vpp，但相位滞后属于正常现象。", { indent: 420 }));
  c.push(h2("电路优缺点分析"));
  c.push(paragraph("本电路优点是分级清晰、便于调试，所有核心功能均可由 LM324 运算放大器完成；三处示波器观察点使问题定位更直接。缺点是三角波幅度对施密特触发阈值较敏感，滤波器输出幅度受电阻电容精度和运放带宽影响，若进行实物搭建，关键电阻建议使用精密电阻或可调电阻。", { indent: 420 }));
  c.push(h2("调试收获与 AI 辅助说明"));
  c.push(paragraph("旧版电路曾出现三角波幅度偏大的问题，测得约 7.120 Vpp，远高于约 4 Vpp 的目标。该问题作为调试反例分析，而不是设计主线的起点。根据幅度比例可得：", { indent: 420 }));
  c.push(equation([frac([m("4.000")], [m("7.120")]), m("≈0.562")]));
  c.push(equation([m("130 kΩ×0.562≈73.1 kΩ")]));
  c.push(paragraph("因此选择接近标准值的 75 kΩ，并进一步将 C1 从 68 nF 增大到 110 nF，用更大的积分时间常数补偿周期变化。AI 辅助主要用于整理课程要求、检索运放与滤波器资料、恢复 Multisim 自动化工具链、对照波形读数推理参数修正方向，并生成报告和 skill 包；最终判断仍以 Multisim 仿真结果、示波器光标读数和课程指标为准。", { indent: 420 }));
  c.push(equation([frac([m("75")], [m("130")]), m("≈0.577")]));
  c.push(...imageBlock(figs.failed));

  c.push(h1("参考文献"));
  references.forEach((ref, index) => c.push(paragraph(`[${index + 1}] ${ref}`, { size: 22, line: 320 })));

  return c;
}

async function build() {
  fs.mkdirSync(outputsDir, { recursive: true });
  const outAssets = path.join(outputsDir, "assets");
  fs.mkdirSync(outAssets, { recursive: true });
  Object.values(figs).forEach(([file]) => fs.copyFileSync(path.join(assetsDir, file), path.join(outAssets, file)));
  fs.copyFileSync(files.logo, path.join(outAssets, "sichuan_university_logo.png"));

  const markdown = buildMarkdown();
  fs.writeFileSync(files.md, markdown, "utf8");
  fs.writeFileSync(files.html, markdownToHtml(markdown), "utf8");

  const doc = new Document({
    styles: {
      default: { document: { run: { font: "宋体", size: 24 } } },
      paragraphStyles: [
        {
          id: "Heading1",
          name: "Heading 1",
          basedOn: "Normal",
          next: "Normal",
          quickFormat: true,
          run: { size: 32, bold: true, font: "黑体" },
          paragraph: { spacing: { before: 260, after: 150 }, outlineLevel: 0 },
        },
        {
          id: "Heading2",
          name: "Heading 2",
          basedOn: "Normal",
          next: "Normal",
          quickFormat: true,
          run: { size: 27, bold: true, font: "黑体" },
          paragraph: { spacing: { before: 180, after: 90 }, outlineLevel: 1 },
        },
      ],
    },
    sections: [{
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1134, right: 1134, bottom: 1134, left: 1134 },
        },
      },
      children: buildDocxChildren(),
    }],
  });

  fs.writeFileSync(files.docx, await Packer.toBuffer(doc));
  [files.docx, files.md, files.html].forEach((file) => fs.copyFileSync(file, path.join(outputsDir, path.basename(file))));
  console.log(JSON.stringify({ files, outputsDir }, null, 2));
}

build().catch((error) => {
  console.error(error);
  process.exit(1);
});
