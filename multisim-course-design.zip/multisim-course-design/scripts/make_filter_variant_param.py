from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import win32com.client


def estimate(r10: float, r11: float, r12: float, r13: float, c2: float, c4: float) -> dict[str, float]:
    k = 1.0 + r13 / r12
    # Equal-cap Sallen-Key exact formulas.
    w0 = 1.0 / math.sqrt(r10 * r11 * c2 * c4)
    fc = w0 / (2.0 * math.pi)
    q = math.sqrt(r10 * r11 * c2 * c4) / (c2 * (r10 + r11) + c4 * r10 * (1.0 - k))

    def gain(freq_hz: float) -> float:
        ratio = freq_hz / fc
        denom = math.sqrt((1.0 - ratio * ratio) ** 2 + (ratio / q) ** 2)
        return k / denom

    g500 = gain(500.0)
    g5000 = gain(5000.0)
    return {
        "K": k,
        "Q": q,
        "fc_hz": fc,
        "gain_500": g500,
        "gain_5000": g5000,
        "uo2_vpp_est": 4.0 * g500,
        "triangle_residue_vpk_est": 1.6211389382774044 * g5000,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--dest", required=True)
    parser.add_argument("--r10", type=float, required=True)
    parser.add_argument("--r11", type=float, required=True)
    parser.add_argument("--r13", type=float, required=True)
    parser.add_argument("--json-out")
    args = parser.parse_args()

    source = Path(args.source)
    dest = Path(args.dest)
    dest.parent.mkdir(parents=True, exist_ok=True)

    app = win32com.client.gencache.EnsureDispatch("MultisimInterface.MultisimApp")
    app.Connect()
    doc = app.OpenFile(str(source))

    before = {name: float(doc.RLCValue(name)) for name in ("R10", "R11", "R12", "R13", "C2", "C4")}
    updates = {"R10": args.r10, "R11": args.r11, "R13": args.r13}
    changed: dict[str, dict[str, float]] = {}
    for name, value in updates.items():
        prev = float(doc.RLCValue(name))
        doc.SetRLCValue(name, float(value))
        changed[name] = {"before": prev, "after": float(doc.RLCValue(name))}

    saved = bool(doc.SaveAs(str(dest)))
    summary = estimate(
        r10=float(doc.RLCValue("R10")),
        r11=float(doc.RLCValue("R11")),
        r12=float(doc.RLCValue("R12")),
        r13=float(doc.RLCValue("R13")),
        c2=float(doc.RLCValue("C2")),
        c4=float(doc.RLCValue("C4")),
    )

    payload = {
        "source": str(source),
        "dest": str(dest),
        "saved": saved,
        "before": before,
        "changed": changed,
        "estimate": summary,
    }
    if args.json_out:
        out_path = Path(args.json_out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
