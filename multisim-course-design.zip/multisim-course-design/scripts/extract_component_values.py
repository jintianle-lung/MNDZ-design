from __future__ import annotations

import argparse
import json

import win32com.client


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("path")
    args = parser.parse_args()

    app = win32com.client.Dispatch("MultisimInterface.MultisimApp")
    app.Connect()
    doc = app.OpenFile(args.path)

    results = {}
    enum_results = {}
    for filter_type in range(0, 8):
        try:
            enum_results[str(filter_type)] = list(doc.EnumComponents(filter_type))
        except Exception as exc:
            enum_results[str(filter_type)] = {"error": str(exc)}

    components = []
    for value in enum_results.values():
        if isinstance(value, list):
            for item in value:
                if item not in components:
                    components.append(item)

    for name in components:
        try:
            results[name] = doc.RLCValue(name)
        except Exception as exc:
            results[name] = {"error": str(exc)}

    print(json.dumps({"enum_results": enum_results, "values": results}, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
